package demo;

import java.util.Properties;

import org.webchunks.base.servlet.WebChunksServlet;

/**
 *
 * @author Petr Zalyautdinov (Заляутдинов Пётр) <zalyautdinov.petr@gmail.com>
 */
public class WcDemoServlet extends WebChunksServlet<WcDemoApplication> {

    @Override
    protected WcDemoApplication createApplication(Properties prprts) {
        return new WcDemoApplication(prprts);
    }

}
